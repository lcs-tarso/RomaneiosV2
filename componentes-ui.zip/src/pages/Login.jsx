export default function Login() {
  return (
    <div className="p-8">
      <h1 className="text-xl font-bold">Login</h1>
      <p className="text-gray-600">Seja bem-vindo ao sistema de romaneios.</p>
    </div>
  );
}
